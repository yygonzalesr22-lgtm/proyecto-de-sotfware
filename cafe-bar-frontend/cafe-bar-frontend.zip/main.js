import App from './src/App.jsx'
import { createRoot } from 'react-dom/client'
createRoot(document.getElementById('app')).render(App())