import { useEffect, useState } from 'react'
export default function Inventario(){
  const [items,setItems]=useState([])
  useEffect(()=>{
    fetch('http://localhost:3000/inventario')
      .then(r=>r.json())
      .then(setItems)
  },[])
  return <div><h2>Inventario</h2>{items.map(i=><div key={i.id}>{i.nombre}</div>)}</div>
}
